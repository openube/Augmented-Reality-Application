Created & imported into unity by 3DAutosports.com.

Feel free to use this stockcar model for any type of race project!

Contact us if you have questions.