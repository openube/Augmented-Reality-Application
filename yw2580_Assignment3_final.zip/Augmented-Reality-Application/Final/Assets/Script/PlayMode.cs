﻿using UnityEngine;
using System.Collections;

public class PlayMode : MonoBehaviour {

	public GameObject CloneCar = null;
	public GameObject originCar = null;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

		//Debug.Log ("Cube position"+transform.position);

	}
}
